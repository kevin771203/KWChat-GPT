// 儲存訊息內容區塊的 jQuery 物件，用於控制捲動和訊息顯示
var $messages = $('.messages-content'),
    d, h, m, // d: 當前時間的 Date 物件, h: 小時, m: 分鐘
    i = 0;   // i: 用來追踪訊息的索引

// 當視窗加載完成後，初始化自定義的捲軸插件
$(window).on('load', function() {
  $messages.mCustomScrollbar(); // 初始化 jQuery mCustomScrollbar 插件
});

// 更新捲動條，確保訊息顯示在最底部
function updateScrollbar() {
  $messages.mCustomScrollbar("update") // 更新捲軸狀態
            .mCustomScrollbar('scrollTo', 'bottom', { // 滾動到最底部
              scrollInertia: 10,  // 控制滾動的速度
              timeout: 0         // 立即執行滾動
            });
}

// 設置當前訊息的時間戳，若分鐘數不同則顯示時間
function setDate() {
  d = new Date(); // 取得當前時間
  if (m != d.getMinutes()) { // 若分鐘數不同則插入新的時間戳
    m = d.getMinutes(); // 更新分鐘數
    // 確保小時和分鐘前有零
    var hours = String(d.getHours()).padStart(2, '0'); // 小時前加零
    var minutes = String(m).padStart(2, '0'); // 分鐘前加零
    // 在最後一條訊息後面插入時間戳
    $('<div class="timestamp">' + hours + ':' + minutes + '</div>').appendTo($('.message:last'));
  }
}

// 插入新的個人訊息
function insertMessage() {
  var msg = $('.message-input').val(); // 取得輸入框中的訊息
  if ($.trim(msg) === '') { // 若訊息為空則不做任何操作
    return false;
  }

  // 將個人訊息以 HTML 安全方式插入訊息內容區
  $('<div class="message message-personal">' + escapeHtml(msg) + '</div>').appendTo($('.mCSB_container')).addClass('new');
  setDate(); // 設置訊息的時間戳
  $('.message-input').val(null); // 清空輸入框
  updateScrollbar(); // 更新捲軸，確保滾動到最底部

  // 發送消息到後端
  $.ajax({
    type: "POST", // 發送 POST 請求
    url: "/chat", // 發送到 /chat 端點
    contentType: "application/json", // 設置發送內容的格式為 JSON
    data: JSON.stringify({ message: msg }), // 將訊息轉換為 JSON 格式發送
    success: function(data) {
      // 將後端返回的訊息中的網址轉換為可點擊的連結
      var messageWithLinks = convertUrlsToLinks(data.response); // 使用 data.response 來獲取機器人的回覆

      // 插入新的來自後端的訊息，並附上頭像
      $('<div class="message new"><figure class="avatar"><img src="https://s3-us-west-2.amazonaws.com/s.cdpn.io/156381/profile/profile-80.jpg" /></figure>' + messageWithLinks + '</div>').appendTo($('.mCSB_container')).addClass('new');
      setDate(); // 設置訊息的時間戳
      updateScrollbar(); // 更新捲軸
    },
    error: function(err) {
      // 如果發送失敗，顯示錯誤訊息
      $('<div class="message new"><figure class="avatar"><img src="https://s3-us-west-2.amazonaws.com/s.cdpn.io/156381/profile/profile-80.jpg" /></figure>Error: ' + err.responseJSON.error + '</div>').appendTo($('.mCSB_container')).addClass('new');
      setDate(); // 設置錯誤訊息的時間戳
      updateScrollbar(); // 更新捲軸
    }
  });
}

// 將字串中的特殊字符進行轉義，以防止 XSS 攻擊
function escapeHtml(text) {
  return text
    .replace(/&/g, "&amp;") // 將 & 轉換為 &amp;
    .replace(/</g, "&lt;")  // 將 < 轉換為 &lt;
    .replace(/>/g, "&gt;")  // 將 > 轉換為 &gt;
    .replace(/"/g, "&quot;") // 將 " 轉換為 &quot;
    .replace(/'/g, "&#039;"); // 將 ' 轉換為 &#039;
}

function convertUrlsToLinks(text) {
  var urlPattern = /(\b(https?|ftp|file):\/\/[-A-Z0-9+&@#\/%?=~_|!:,.;]*[-A-Z0-9+&@#\/%=~_|])/ig;
  return text.replace(urlPattern, '<br><a href="$1" target="_blank">$1</a><br>'); // 將網址轉換為超連結
}

// 當點擊 "送出" 按鈕時，執行插入訊息的功能
$('.message-submit').click(function() {
  insertMessage();
});

// 當按下 Enter 鍵時，執行插入訊息的功能
$(window).on('keydown', function(e) {
  if (e.which === 13) { // 檢查是否按下 Enter 鍵
    insertMessage(); // 插入訊息
    return false; // 阻止 Enter 鍵的預設行為 (例如換行)
  }
});
